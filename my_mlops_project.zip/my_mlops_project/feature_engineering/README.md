# Feature Engineering
To set up the feature engineering job via scheduled Databricks workflow, please refer to [my_mlops_project/resources/README.md](../resources/README.md)

For additional details on using the feature store, please refer to [the project-level README](../README.md).
